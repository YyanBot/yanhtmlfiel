const express = require('express');
const app = express();

app.use(express.json()); // Untuk menerima data JSON

app.post('/api/jalankan-bot', (req, res) => {
  try {
    // Jalankan file bot.js
    const childProcess = require('child_process');
    childProcess.exec('node bot.js', (error, stdout, stderr) => {
      if (error) {
        res.status(500).json({ message: error.message });
      } else {
        res.json({ message: 'Bot berhasil dijalankan' });
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server berjalan di port 3000');
});