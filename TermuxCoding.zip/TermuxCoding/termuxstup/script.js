const tombolKirim = document.getElementById('tombol-kirim');
const pertanyaanInput = document.getElementById('pertanyaan');
const jawabanDiv = document.getElementById('jawaban');

tombolKirim.addEventListener('click', function() {
  const pertanyaan = pertanyaanInput.value;
  const apiKey = 'https://aihub.xtermai.xyz'; // Ganti dengan API Key Anda
  const url = `https://aihub.xtermai.xyz/api/jawab?apikey=${apiKey}&pertanyaan=${pertanyaan}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const jawaban = data.jawaban;
      jawabanDiv.innerText = jawaban;
    })
    .catch(error => console.error(error));
});

fetch('data.json')
  .then(response => response.json())
  .then(data => {
    // Gunakan data dari file JSON
  })
  .catch(error => {
    console.error(error);
  });