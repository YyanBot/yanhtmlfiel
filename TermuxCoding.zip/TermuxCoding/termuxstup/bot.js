
const WhatsApp = require('whatsapp-web.js');

const wa = new WhatsApp('nama_bot', 'nomor_bot');

wa.on('message', (msg) => {
  console.log(msg.body);
  // Balas pesan
  wa.sendMessage(msg.from, 'Halo!');
});

wa.init();